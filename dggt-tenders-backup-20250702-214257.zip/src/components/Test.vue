<template>
  <div class="max-w-5xl mx-auto p-8">
    <h1 class="text-3xl font-bold mb-6">Test simple</h1>
    <div class="bg-green-100 p-4 rounded">Si tu vois ce texte, Vue fonctionne !</div>
  </div>
</template>
<script setup lang="ts">
</script> 