<template>
  <div style="padding:2rem;">
    <RolesPermissionsEditor />
  </div>
</template>

<script setup lang="ts">
import RolesPermissionsEditor from './RolesPermissionsEditor.vue'
</script> 